﻿#region Codes
#region ClassSet
#region Using
using System; //System Library ( Windows(Main) )
using System.Diagnostics; //Process Library
using System.IO; //WebClient Library
using System.IO.Compression; //Zip File Library
using System.Net; //Directory Library
using System.Threading; //Thread Library
#endregion

#region NameSpace
namespace ConsoleDownloader
{
    class Program //Class Add
    {
        #endregion

        #endregion

#region MainCodes
        #region Main
        static void Main(string[] args) //Main
        {
            StartMessage(); //Play StartMessage Function
            Console.WriteLine("Install Successfully! / Custom Message"); //Add Custom Message
            Console.ReadKey(); //Continue If Key is Pressed 
        }
        #endregion

        #region StartMessage
        public static void StartMessage() //Function
        {
            Console.WriteLine("Welcome to **** Downloader! / Custom Message"); //Add Custom Message
            Thread.Sleep(1000); //Wait 1000 Milliseconds
            Console.WriteLine("Press Any Key + Custom Message"); //Add Custom Message
            Console.ReadKey(); //Continue If Key is Pressed 
            Thread.Sleep(200); //Wait 200 Milliseconds
            Console.Clear(); //Clear Console
            Console.WriteLine("File Download Started / Custom Message"); //Add Custom Message
            Prepare(); //Play Prepare Function
            Console.ReadKey(); //Continue If Key is Pressed 
        }
        #endregion

        #region Prepare
        public static void Prepare() //Function
        {
            Console.ForegroundColor = ConsoleColor.Red; //Set Text Color Red
            Console.Write("Preparing . . . / Custom Message"); //Add Custom Message
            Console.ForegroundColor = ConsoleColor.White; //Set Textt Color White
            using (ProgressBar progressBar = new ProgressBar()) //Use ProgressBar Class
            {
                for (int i = 0; i <= 150; i++) //Loop
                {
                    progressBar.Report((double)i / 150.0); //Percent Seconds
                    Thread.Sleep(10); //Wait 10 Milliseconds
                }
            }
            Console.WriteLine(" Done! / Custom Message"); //Add Custom Message
            string path = ".\\Name"; //Add Custom FileName
            bool flag = Directory.Exists(path); //Set Path
            if (flag) //Path If
            {
                try
                {
                    Directory.Delete(path, true); //If There is a File with the Same Name in the Directory = Delete
                    Thread.Sleep(1700); //Wait 1700 Milliseconds
                }
                catch (Exception ex) //If Error
                {
                    Console.ForegroundColor = ConsoleColor.White; //Set Text Color White
                    Console.WriteLine("Something Wrong . . . / Custom Message" + ex.ToString()); //Add Custom Message
                }
            }
            Console.ForegroundColor = ConsoleColor.Yellow; //Set Text Color Yellow
            Download(); //Play Download Function
        }
        #endregion

        #region Download
        public static void Download() //Function
        {
            Console.ForegroundColor = ConsoleColor.Green; //Set Text Color Green
            Console.Write("Downloading . . . / Custom Message"); //Add Custom Message
            Console.ForegroundColor = ConsoleColor.White; //Set Text Color White
            using (ProgressBar progressBar = new ProgressBar()) //Use ProgressBar Class
            {
                for (int i = 0; i <= 250; i++) //Loop
                {
                    progressBar.Report((double)i / 250.0); //Percent Seconds
                    Thread.Sleep(20); //Wait 20 Milliseconds
                }
            }
            Console.WriteLine(" Done!"); //Add Custom Message
            WebClient webClient = new WebClient();  //New Webclient
            webClient.DownloadFileAsync(new Uri("Your File Download URL"), ".\\Name.zip"); //Add Custom Message / FileName
            Extract(); //Play Extract Function
        }
        #endregion

        #region Extract
        public static void Extract() //Function
        {
            Console.ForegroundColor = ConsoleColor.Blue;  //Set Text Color Blue
            Console.Write("Extracting . . . "); //Add Custom Message
            Console.ForegroundColor = ConsoleColor.White; //Set Text Color White
            using (ProgressBar progressBar = new ProgressBar()) //Use ProgressBar Function
            {
                for (int i = 0; i <= 150; i++) //Loop
                {
                    progressBar.Report((double)i / 150.0); //Percent Seconds
                    Thread.Sleep(20); //Wait 20 Milliseconds
                }
            }
            Console.WriteLine(" Done! / Custom Message"); //Add Custom Message
            string sourceArchiveFileName = ".\\Name.zip";  //Add Custom FileName
            ZipFile.ExtractToDirectory(sourceArchiveFileName, ".\\Name"); //Add Custom FileName
            Thread.Sleep(1000); //Wait 1000 Milliseconds
            string path = ".\\Name.zip"; //Add Custom FileName
            bool flag = File.Exists(path); //Exist Path
            if (flag) //If Path
            {
                try
                {
                    File.Delete(path); //Path Delete
                    Thread.Sleep(1000); //Wait 1000 Milliseconds
                }
                catch (Exception ex) //If Error
                {
                    Console.ForegroundColor = ConsoleColor.White; //Set Text Color White
                    Console.WriteLine("Something Wrong . . . / Custom Message" + ex.ToString()); //Add Custom Message
                }
            }
            StartProcess(); //Play StartProcess Function
        }
        #endregion

        #region StartProcess
        public static void StartProcess() //Function
        {
            string fileName = ".\\Name\\Name.exe"; //Add Custom FileName
            Process.Start(fileName); //FileName Start
            Thread.Sleep(600); //Wait 600 Milliseconds
            Console.ForegroundColor = ConsoleColor.White; //Set Text Color White
            Console.WriteLine("Starting Process . . . Done! / Custom Message"); //Add Custom Message
        }
    }
}
#endregion
#endregion
#endregion