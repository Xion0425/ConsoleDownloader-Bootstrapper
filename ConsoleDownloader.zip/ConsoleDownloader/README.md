   _____                      _                            
  / ____|                    | |                           
 | |     ___  _ __  ___  ___ | | ___                       
 | |    / _ \| '_ \/ __|/ _ \| |/ _ \                      
 | |___| (_) | | | \__ \ (_) | |  __/                      
  \_____\___/|_| |_|___/\___/|_|\___|          _           
 |  __ \                    | |               | |          
 | |  | | _____      ___ __ | | ___   __ _  __| | ___ _ __ 
 | |  | |/ _ \ \ /\ / / '_ \| |/ _ \ / _` |/ _` |/ _ \ '__|
 | |__| | (_) \ V  V /| | | | | (_) | (_| | (_| |  __/ |   
 |_____/ \___/ \_/\_/ |_| |_|_|\___/ \__,_|\__,_|\___|_|   
              
--------------------------------------------------

##ConsoleDownloader 1.2

ConsoleDownloader is a Bootstrapping Console Sample Project.
This is an Educational Code Snippet for Desktop Application Programmers.

--------------------------------------------------

##1. How to Code?

(1) What is "/" ?
    also, and, or

(2) What is "+" ?
    Add Unicode

(3) What is "****" ?
    Variable to put in the Message

(4) What is "Custom Message"?
    You can Write Any Message You Want

(5) What is "Custom FIleName"?
    You can Write Any FileName You Want

--------------------------------------------------

## 2. License

 MIT License 

 --------------------------------------------------

##3. Creater

 Xion0425 : Code, Github Manage

 --------------------------------------------------